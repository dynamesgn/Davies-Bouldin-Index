import java.awt.*;
import javax.swing.JOptionPane;
import java.util.Random;

public class FCM{
  Image imageIn;
  //input[transparency][R][G][B] each 2-D array consists of width(row)*height(cols)
  int[][][] input;
  int cluster;
  double fuzziness;
  Dimension imageInDimension;
  int width;
  int height;
  int dim;
  int[][] clusterColor;

  //FCM Constructor
  FCM(Image imageIn,int[][][] input,int cluster, double fuzziness){
    this.imageIn=imageIn;                                             //Input image
    this.input=input;                                                 //Input 3-D array?
    this.cluster=cluster;                                             //Num of clusters
    this.fuzziness=fuzziness;                                         //Fuzziness Index
    imageInDimension = ImageTools.getImageDimension(this.imageIn);    //Get dimensions of picture
    width=(int)imageInDimension.getWidth();                           //column
    height=(int)imageInDimension.getHeight();                         //row
    dim=input.length;                                                 //num of channels TRGB
    clusterColor=ImageTools.getClustersColor(cluster);
  }

  public Image get_FCM(){
    int update[][][] = new int[dim][this.width][this.height];
    double term=0.00001;
    double membership[][][] = new double[width][height][cluster];
    double temp_membership[][][]= new double[width][height][cluster];
    int[][] clusterColor=ImageTools.getClustersColor(this.cluster);
    double kCenters[][]=new double[this.cluster][dim];
    int max=0;


    //Initialize Membership
    membership=initialize_membership();


    //Cluster Center
    kCenters=get_Cluster_Center(membership);

    while(true){
      max++;
      temp_membership=get_membership(kCenters);
      update=get_output(kCenters,temp_membership);
      System.out.println("I'm at iteration "+max);

      //Check Termination Condition
      if(ImageTools.compareArray(membership,temp_membership,term) || max==1000){
        System.out.println("FCM - Xei And Beni: "+ImageTools.compactnessAndSeparationMetric(input,ImageTools.getNormalize(membership),kCenters,this.fuzziness));
        System.out.println("FCM - iIndex: "+ImageTools.iIndex(input,ImageTools.getNormalize(membership),kCenters,this.fuzziness));
        System.out.println("Outer Loop Ran "+max+" times");
        System.out.println("--- \t --- \t ---");
        System.out.println("This is the cluster centers:\t\n");

//        System.out.println("This is the nubmer of Clusters:\t"+kCenters.length);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[0].length);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[0][0]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[0][1]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[0][2]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[0][3]);
//
//        System.out.println("This is the number of Datapoints C2:\t"+kCenters[1].length);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[1][0]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[1][1]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[1][2]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[1][3]);
//        System.out.println("This is the number of Datapoints C3:\t"+kCenters[2].length);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[2][0]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[2][1]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[2][2]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[2][3]);
//        System.out.println("This is the number of Datapoints C4:\t"+kCenters[3].length);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[3][0]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[3][1]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[3][2]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[3][3]);
//        System.out.println("This is the number of Datapoints C5:\t"+kCenters[4].length);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[4][0]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[4][1]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[4][2]);
//        System.out.println("This is the number of Datapoints C1:\t"+kCenters[4][3]);
//
//        System.out.println("This is the input length(num of 2-d arr:)\t"+ input.length);
//        System.out.println("This is the input row length[0][0](num of 2-d arr:)\t"+ input[0].length);
//        System.out.println("This is the input col length[0][0][0](num of 2-d arr:)\t"+ input[0][0].length);
//        System.out.println("This is the input row length[1][0](num of 2-d arr:)\t"+ input[1].length);
//        System.out.println("This is the input col length[1][0][0](num of 2-d arr:)\t"+ input[1][0].length);
//        System.out.println("This is the input row length[2][0](num of 2-d arr:)\t"+ input[2].length);
//        System.out.println("This is the input col length[2][0][0](num of 2-d arr:)\t"+ input[2][0].length);
//        System.out.println("This is the input row length[3][0](num of 2-d arr:)\t"+ input[3].length);
//        System.out.println("This is the input col length[3][0][0](num of 2-d arr:)\t"+ input[3][0].length);
//
//        System.out.println("This is the size\t"+ input[0].length*input[0][0].length);
//
//        System.out.println("This is the membership length(num of 2-d arr:)\t"+ membership.length);
//        System.out.println("This is the membership row length[0](num of 2-d arr:)\t"+ membership[0].length);
//        System.out.println("This is the memberpship col length[0][0](num of 2-d arr:)\t"+ membership[0][0].length);
          int[][] index_list = new int[(input[0].length)][(input[0][0].length)];
//        System.out.println("This is the input[0].length " + input[0].length +"\nThis is the input[0][0].length" + input[0][0].length);

        for (int i = 0; i<membership.length;i++) {
          for (int j = 0; j < membership[0].length; j++){
            for (int k = 0; k<membership[0][0].length;k++)
              //System.out.println("Component " +k + ":\t" +membership[i][j][k]);
              if(membership[i][j][k] == 1.0) {
                index_list[i][j] = k;
              }
          }
        }

        System.out.println("Calculating the dbIndex..");
        System.out.println("This is the dbIndex:\t\n" + ImageTools.dbIndex(input,kCenters,index_list));





        // for(int row = 0; row < kCenters[0].length; row++){
        //   System.out.print("Cluster\t"+row+"contains:\n");
        //   for(int col = 0; col < kCenters[0]; row++){
        //     System.out.print(membership[cluster])
        //   }
        // }

        break;

      }
      else{
        //update membership
        membership=temp_membership;
        kCenters=get_Cluster_Center(membership);
      }
    }
    return ImageTools.pixelsArrayToImage(ImageTools.TRGBArrayToPixelsArray(update, imageInDimension), imageInDimension);
  }

  private double[][][] initialize_membership(){
    double[][][] membership = new double[this.width][this.height][this.cluster];
    Random rand=new Random();
    for (int row = 0; row < this.imageInDimension.getHeight(); row++){
      for (int column = 0; column < this.imageInDimension.getWidth(); column++)
      {
        double sum_Prob=0.0;
        double remaining_Prob=100.0;
        for(int i=0;i<cluster-1;i++){
          double ran=rand.nextDouble()*remaining_Prob;
          sum_Prob+=ran/100;
          remaining_Prob-=ran;
          membership[column][row][i]=ran/100;
        }
        membership[column][row][cluster-1]=1-sum_Prob;
      }
    }
    return membership;

  }

  private double[][] get_Cluster_Center(double[][][] membership){
    double[][] kCenters = new double[this.cluster][dim];
    for(int i=0;i<kCenters.length;i++){//cluster
      for(int j=1;j<kCenters[i].length;j++){//RGB
        double num=0.0;
        double den=0.0;
        for (int row = 0; row < this.imageInDimension.getHeight(); row++){
          for (int column = 0; column < this.imageInDimension.getWidth(); column++)
          {

            num+=this.input[j][column][row]*(Math.pow(membership[column][row][i],this.fuzziness));
            den+=Math.pow(membership[column][row][i],this.fuzziness);
          }
        }
        Double ans = num/den;
         if(Double.isNaN(ans)){
           System.err.println("Invalid center value for cluster"+i+" and dimension"+j);
           ans=0.0;
           throw new IllegalArgumentException();

         }
        //System.out.println(sum/den);
        kCenters[i][j]=ans;

      }
    }
    return kCenters;

  }

  private double[][][] get_membership(double[][] kCenters){
    double[][][] temp_membership=new double[this.width][this.height][this.cluster];

    for(int curr=0;curr<kCenters.length;curr++){//specific cluster for sum
      for (int row = 0; row < this.imageInDimension.getHeight(); row++){
        for (int column = 0; column < this.imageInDimension.getWidth(); column++)
        {
          double diff=0;
          double coff=2/(this.fuzziness-1);
          double neu=0;
          double den=0;
          double sum=0;
          for(int j=0;j<kCenters.length;j++){//all cluster
            for(int d=1;d<this.dim;d++){
              den+=(Math.pow(this.input[d][column][row]-kCenters[j][d],2));
              neu+=(Math.pow(this.input[d][column][row]-kCenters[curr][d],2));
            }
            den=Math.sqrt(den);
            neu=Math.sqrt(neu);
            double div=Math.pow((neu/den),coff);
            sum+=div;

          }
          temp_membership[column][row][curr]=1/sum;

        }//column end
      }//row end
    }//cluster end

    return temp_membership;

  }


  private int[][][] get_output(double[][] kCenters, double[][][] temp_membership){
    int update[][][] = ImageTools.pixelsArrayToTRGBArray(ImageTools.imageToPixelsArray(this.imageIn), this.imageInDimension);
    for (int row = 0; row < this.imageInDimension.getHeight(); row++){
      for (int column = 0; column < this.imageInDimension.getWidth(); column++)
      {
        int select=0;
        double val=temp_membership[column][row][0];
        for(int curr=0;curr<kCenters.length;curr++){
          if(temp_membership[column][row][curr]>val){
            val=temp_membership[column][row][curr];
            select=curr;
          }
        }
        for(int i=1;i<4;i++){//RGB
          update[i][column][row]=(int)kCenters[select][i];
        }

      }
    }
    return update;
  }

    public double[][][] get_FCM_membership(){
    int update[][][] = new int[dim][this.width][this.height];
    double term=0.00001;
    double membership[][][] = new double[width][height][cluster];
    double temp_membership[][][]= new double[width][height][cluster];
    int[][] clusterColor=ImageTools.getClustersColor(this.cluster);
    double kCenters[][]=new double[this.cluster][dim];
    int max=0;


    //Initialize Membership
    membership=initialize_membership();


    //Cluster Center
    kCenters=get_Cluster_Center(membership);

    while(true){
      max++;
      temp_membership=get_membership(kCenters);
      update=get_output(kCenters,temp_membership);

      if(ImageTools.compareArray(membership,temp_membership,term) || max==1000){
        System.out.println("Outer Loop Ran "+max+" times");
        System.out.println("iIndex: "+ImageTools.iIndex(input,ImageTools.getNormalize(membership),kCenters,this.fuzziness));
        System.out.println("Xei And Beni: "+ImageTools.compactnessAndSeparationMetric(input,ImageTools.getNormalize(membership),kCenters,this.fuzziness));
        break;

      }else{
        //update membership
        membership=temp_membership;
        kCenters=get_Cluster_Center(membership);
      }
    }
    return membership;
  }















}
