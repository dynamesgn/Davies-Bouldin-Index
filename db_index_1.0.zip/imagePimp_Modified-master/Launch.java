public class Launch{
  public static void main(String[] args){
    ImagePimpMinh img=new ImagePimpMinh();   
  }
}